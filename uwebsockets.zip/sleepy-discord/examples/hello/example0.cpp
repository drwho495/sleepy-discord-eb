#include <sleepy_discord/sleepy_discord.h>
#include <rapidjson/fwd.h>
#include <stdio.h>
#include <sqlite3.h> 
#include <stdlib.h>


using namespace rapidjson;
using namespace std;

const vector<string> explode(const string& s, const char& c)
{
	string buff{""};
	vector<string> v;
	
	for(auto n:s)
	{
		if(n != c) buff+=n; else
		if(n == c && buff != "") { v.push_back(buff); buff = ""; }
	}
	if(buff != "") v.push_back(buff);
	
	return v;
}

static int callback(void *data, int argc, char **argv, char **azColName){
   int i;
   fprintf(stderr, "%s: ", (const char*)data);
   
	 string id = "";
	 string job = "";
	 string money = "";

   for(i = 0; i<argc; i++){
			if(strcmp(azColName[i], "id") == 0) {
				id = argv[i];
			}
   }

	 cout << id + "\n";
   
   return 0;
}

static int insertCallback(void *NotUsed, int argc, char **argv, char **azColName) {
   int i;
   for(i = 0; i<argc; i++) {
      printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
   }
   printf("\n");
   return 0;
}

class MyClientClass : public SleepyDiscord::DiscordClient {
public:
	using SleepyDiscord::DiscordClient::DiscordClient;
	void onMessage(SleepyDiscord::Message message) override {
		if(message.startsWith("cb! ")) {
				string msgRaw = message.content;

				cout << message.author.ID.string() + "\n";

				if(msgRaw.length() > 4) {

				string msg = msgRaw.substr(4, msgRaw.length());

				cout << msg << '\n';

				std::vector<string> cmd = explode(msg, ' ');

				if(cmd[0] == "test") {
					sendMessage(message.channelID, "Hello " + message.author.username);

					const char* json = "{\"project\":\"rapidjson\",\"stars\":10}";
					char *zErrMsg = 0;
					string data = "Callback function called";
					Document d;
					d.Parse(json);

					int rc;
					sqlite3 *db;

          rc = sqlite3_open("main", &db);

					rc = sqlite3_exec(db, "SELECT * FROM jobs", callback, 0, &zErrMsg);

					if( rc != SQLITE_OK ) {
							fprintf(stderr, "SQL error: %s\n", zErrMsg);
							sqlite3_free(zErrMsg);
					} else {
							fprintf(stdout, "Operation done successfully\n");
					}
					sqlite3_close(db);
				} else if(cmd[0] == "new") {

					if(cmd.size() > 1) {
						if(cmd[1] == "discord-user") {
							sqlite3 *db;
							char *zErrMsg = 0;
							int rc;
							string sql;

							/* Open database */
							rc = sqlite3_open("main", &db);
							
							if( rc ) {
									fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
							}

							/* Create SQL statement */
							sql = "INSERT INTO JOBS (id, job, money) VALUES('" + message.author.ID.string() + "', '" + cmd[1] + "', '100')";

							/* Execute SQL statement */
							rc = sqlite3_exec(db, sql.c_str(), insertCallback, 0, &zErrMsg);
							
							if( rc != SQLITE_OK ){
									fprintf(stderr, "SQL error: %s\n", zErrMsg);
									sqlite3_free(zErrMsg);
							}
							sqlite3_close(db);
						} else {
							sendMessage(message.channelID, "That job does not exist!");
						}
					} else {
						sendMessage(message.channelID, "You must add a job!");
					}

				}
			}
		}
	}
};

int main() {
	MyClientClass client("ODIyMzA5MzY2ODI4NjMwMDI2.YFQZRg.XXdrR_-64qIROwi6bn8-NztqZlk", SleepyDiscord::USER_CONTROLED_THREADS);
	client.run();
}
