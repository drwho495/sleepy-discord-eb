#pragma once
#define NONEXISTENT_ASIO