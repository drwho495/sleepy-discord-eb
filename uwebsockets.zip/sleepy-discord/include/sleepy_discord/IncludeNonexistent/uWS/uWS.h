#pragma once
#define NONEXISTENT_UWEBSOCKETS