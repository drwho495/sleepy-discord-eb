#pragma once
#define NONEXISTENT_BOOST_ASIO